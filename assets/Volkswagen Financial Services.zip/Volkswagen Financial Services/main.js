var calculator = new Calculator();
var request = {
    Request: {
        "@Name": "Defaults",
        "@Domains": "VW.NEW",
        Vehicle: {
            "Key": "5G13BX\\GPJ3PJ3\\GPU2PU2\\GZCBZCB",
            "Year": "2015",
            "PriceTotal": "30000"
        }
    }
}

calculator.getCalculatorReady(function (res) {
    document.getElementById("result").innerHTML += res;

    calculator.getInterface(JSON.stringify(request), {
        ResultContainer: document.getElementById("resultContainer"),
        Summary: {
            Type: "Medium",
            Container: document.getElementById("summaryContainer")
        },
        Disclaimer: {
            Container: document.getElementById("disclaimerContainer")
        },
        Callback: function (ans) {
            console.info(ans);
        }
    })
});